# SeminarKu (Laravel)

Sistem Informasi Pencarian Seminar dan E-Sertifikat Berbasis Web, versi **Laravel**.
Ini adalah hasil porting dari versi PHP biasa: fitur, aturan, tampilan, dan data contoh sama; strukturnya sekarang MVC Laravel.

> **Status pengujian.** Kode ini sudah diperiksa sintaksnya (semua file PHP dan tampilan) dan seluruh nama rute sudah dicek konsisten,
> tetapi **belum pernah dijalankan di dalam Laravel**, karena lingkungan tempat kode ini ditulis tidak bisa mengunduh paket Composer.
> Jalankan sekali di komputer Anda; bila ada pesan error, kirim pesannya agar diperbaiki.

## Teknologi
Laravel 11 atau 12, PHP 8.2+, Blade, Eloquent, SQLite (bawaan) atau MySQL/MariaDB. Tanpa paket tambahan (PDF sertifikat dibuat sendiri, QR dibuat di browser).

## Cara pasang

### Otomatis (Linux, macOS, Git Bash di Windows)
```bash
bash install.sh seminarku-app
cd seminarku-app
php artisan serve
```
Buka http://127.0.0.1:8000

### Manual (semua sistem, termasuk Laragon/XAMPP)
1. `composer create-project laravel/laravel seminarku-app`
2. Hapus isi `database/migrations/`, `database/factories/UserFactory.php`, dan `tests/Feature/ExampleTest.php`.
3. Salin **isi folder `src/`** ke dalam `seminarku-app/` (timpa file yang sama, termasuk `bootstrap/app.php`).
4. Di `.env` ubah: `APP_NAME=SeminarKu`, `APP_LOCALE=id`, `SESSION_DRIVER=file`, `CACHE_STORE=file`, `QUEUE_CONNECTION=sync`.
5. Di `config/app.php` ubah `'timezone'` menjadi `'Asia/Jakarta'`.
6. Pastikan file `database/database.sqlite` ada (kosong tidak apa-apa), lalu: `php artisan migrate:fresh --seed`
7. `php artisan serve`

### Memakai MySQL
Buat basis data kosong, lalu di `.env`:
```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=seminarku
DB_USERNAME=root
DB_PASSWORD=
```
dan jalankan `php artisan migrate:fresh --seed`.

## Akun contoh
| Peran | Email | Kata sandi |
| --- | --- | --- |
| Admin | admin@seminar.test | admin123 |
| Panitia | panitia@seminar.test | panitia123 |
| Panitia | hmj@seminar.test | hmj12345 |
| Peserta | mhs@seminar.test | mhs12345 |

Akun `ukm@seminar.test` (ukm12345) sengaja berstatus menunggu, untuk mencoba validasi panitia oleh admin.

## Deploy ke hosting atau subdomain (bukan localhost)
1. Unggah seluruh proyek, lalu arahkan **document root** domain/subdomain ke folder `public/`
   (cPanel: Domains > ubah Document Root; atau letakkan isi `public/` di `public_html` dan sesuaikan path di `index.php`).
2. Salin `.env.example` menjadi `.env`, lalu isi: `APP_ENV=production`, `APP_DEBUG=false`, `APP_URL=https://subdomain-anda`, dan data MySQL dari hosting.
3. Jalankan (SSH atau Terminal cPanel): `composer install --no-dev --optimize-autoloader`, `php artisan key:generate`,
   `php artisan migrate --force`, lalu `php artisan config:cache` dan `php artisan route:cache`.
   Data contoh (opsional, jangan di produksi sungguhan): `php artisan db:seed`.
4. Folder `storage/` dan `bootstrap/cache/` harus bisa ditulis (chmod 775). Poster, QRIS, dan bukti bayar tersimpan di `storage/app/.../uploads`
   dan hanya bisa dibuka lewat aplikasi (cek hak akses), bukan lewat URL langsung.
5. Batas unggahan mengikuti `upload_max_filesize` dan `post_max_size` di php.ini (poster maks. 4 MB, QRIS dan bukti bayar maks. 2 MB).

## Peta porting (versi lama ke Laravel)
| Fitur | Versi lama | Laravel |
| --- | --- | --- |
| Masuk, daftar, keluar | login.php, register.php | `AuthController`, `views/auth/*` |
| Beranda publik, ketentuan, verifikasi | index.php, ketentuan.php, verify.php | `HomeController`, `views/pages/*` |
| Cari acara, detail, daftar | events.php, event.php | `EventController`, `views/pages/events/*` |
| Tiket, bukti bayar, presensi kode | tickets.php, ticket.php | `TicketController`, `views/pages/tickets/*` |
| Sertifikat dan PDF | certificates.php, certificate_pdf.php, inc/pdf.php | `CertificateController`, `Services/CertificatePdf` |
| Profil | profile.php | `ProfileController` |
| Beranda kalender | dashboard.php | `DashboardController`, `views/dashboard` |
| Panitia: acara, form, peserta, jelajah, presensi | org_*.php | `Organizer/*Controller`, `views/organizer/*` |
| Admin: pengguna, laporan | admin_users.php, admin_reports.php | `Admin/UserController`, `Admin/ReportController` |
| Chat privat | chat.php, chat_api.php | `ChatController`, `views/chat` |
| Penyaji gambar | file.php | `FileController` (rute `/berkas/{jenis}/{id}`) |
| Skema basis data | inc/db.php | `database/migrations/*` |
| Data contoh | inc/seed_data.php | `database/seeders/*` |
| Fungsi bantu | inc/helpers.php | `app/Support/helpers.php` |
| Cek login dan peran | require_login() | middleware `app`, `organizer` |

Rute ada di `routes/*.php` (dipisah: auth, participant, organizer, admin). Daftar lengkap: `php artisan route:list`.

## Aturan penting yang dipertahankan
- QR tiket hanya tampil bila pendaftaran **disetujui panitia**, acara terbit, dan belum lewat.
- Acara berbayar: peserta membayar lewat QRIS/transfer lalu mengunggah bukti; panitia memeriksa dan menyetujui.
- Chat peserta dan panitia **privat**: admin tidak punya akses (halaman maupun API).
- Sistem mencegah acara ganda dan bentrok lokasi/jam antarpanitia.
- Poster acara (maks. 4 MB) dan QRIS pembayaran (maks. 2 MB) diunggah terpisah.
- Hapus pengguna aman: data terkait ikut dibersihkan; admin terakhir dan akun sendiri tidak bisa dihapus.
- E-sertifikat terbit otomatis saat hadir tercatat, dapat diunduh PDF dan diverifikasi lewat kode.

## Catatan
- Tombol "Keluar" memakai tautan GET agar tampilan tidak berubah. Untuk produksi yang lebih ketat, ganti dengan formulir POST.
- Tema terang/malam disimpan di browser (localStorage), bukan di basis data.
