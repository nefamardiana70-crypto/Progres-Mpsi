#!/usr/bin/env bash
# Memasang SeminarKu (Laravel) ke folder baru.
# Pemakaian:  bash install.sh [nama-folder]      (bawaan: seminarku-app)
# Syarat: PHP 8.2+, Composer, ekstensi PHP sqlite3/pdo_sqlite (atau mysql), mbstring, gd (opsional).
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
APP="${1:-seminarku-app}"

command -v php >/dev/null      || { echo "PHP belum terpasang."; exit 1; }
command -v composer >/dev/null || { echo "Composer belum terpasang (https://getcomposer.org)."; exit 1; }

echo "==> Membuat proyek Laravel di $APP"
composer create-project laravel/laravel "$APP" --no-interaction

cd "$APP"

echo "==> Membersihkan bawaan Laravel yang diganti SeminarKu"
rm -f database/migrations/*.php database/factories/UserFactory.php tests/Feature/ExampleTest.php tests/Unit/ExampleTest.php

echo "==> Menyalin kode SeminarKu"
cp -R "$HERE/src/." .

setenv() {   # setenv KUNCI NILAI : ubah atau tambahkan di .env
    if grep -q "^$1=" .env; then sed -i.bak -E "s#^$1=.*#$1=$2#" .env; else echo "$1=$2" >> .env; fi
}
setenv APP_NAME SeminarKu
setenv APP_LOCALE id
setenv SESSION_DRIVER file
setenv CACHE_STORE file
setenv QUEUE_CONNECTION sync
rm -f .env.bak
sed -i.bak "s#'timezone' => .*#'timezone' => 'Asia/Jakarta',#" config/app.php && rm -f config/app.php.bak

[ -f database/database.sqlite ] || touch database/database.sqlite

echo "==> Membuat tabel dan data contoh"
php artisan migrate:fresh --seed --force

echo
echo "Selesai. Jalankan:  cd $APP && php artisan serve"
echo "Lalu buka http://127.0.0.1:8000   (akun contoh ada di README.md)"
