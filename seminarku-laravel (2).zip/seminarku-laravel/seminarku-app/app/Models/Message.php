<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    const UPDATED_AT = null;

    protected $guarded = [];

    public function event()
    {
        return $this->belongsTo(Event::class);
    }
}
